#include <stdio.h>

int main() {
 
    const int CONTA_CORRETA = 12345;
    const int SENHA_CORRETA = 123;

    int conta, senha;
    int tentativas = 0;
    int acesso_concedido = 0;

    do {
        printf("Digite o número da conta: ");
        scanf("%d", &conta);
        
        printf("Digite a senha: ");
        scanf("%d", &senha);
        
        tentativas++; 
        if (conta == CONTA_CORRETA && senha == SENHA_CORRETA) {
            acesso_concedido = 1;
        }
        
    } while (tentativas < 3 && acesso_concedido == 0);

    if (acesso_concedido == 1) {
        printf("\nAcesso autorizado.\n");
    } else {
        printf("\nAcesso bloqueado.\n");
    }

    return 0;
}
